%% function [M_t_current] = M_tilde_k(gamma,X,YY,YS,S,Y,phi,k,b)
%
%Given the necessary inputs the matrix M_k_tilde is computed according to 
%Algorithm 2 
%%Inputs:
%   gamma       = any real number such that B_0 = gamma*I_n
%   X           = k x 1 vector containing sBs values
%   YY          = k+1 x k+1 matrix
%   YS          = k+1 x k+1 matrix
%   S           = n x k+1 
%   Y           = n x k+1 
%   phi         = 1 x k vector
%   k           = real number; 
%   b           = 1 x k; indicator: if b(i)=0 then phi is SR1
%                                   if b(i)=1 then phi is not SR1
%                                   i= 1,..,k
%Outputs: 
%   M_t_current = rank x rank; matrix M_k_tilde 


function [M_t_current] = M_tilde_k(gamma,X,YY,YS,S,Y,phi,k,b)

s=S(:,1);
y=Y(:,1);

if k == 1 %creates M_tilde_0
   if b(1) ==0
       
       PHI = y'*s/(y'*s-((1/gamma)*(y'*y))); %PHI is the inverse equivalent 
                                             %of phi
       
       beta = -PHI/(y'*s);
       
       M_t_current = -beta;
       
       
       
   else
       PHI = ((1-phi(1))*(y'*s)^2)/((1-phi(1))*(y'*s)^2+phi(1)*((1/gamma)*(y'*y)*(gamma*(s'*s))));
       
       alpha = (1/(s'*y))+PHI*(1/gamma)*(y'*y)/(s'*y)^2;
       beta = -PHI/(y'*s);
       delta = -(1-PHI)/(y'*((1/gamma)*y));
       
       M_t_current = [alpha beta; beta delta];
       
   end

else

    if b(1) ==0
       
       PHI = y'*s/(y'*s-((1/gamma)*(y'*y))); %PHI is the inverse equivalent 
                                             %of phi
       
       beta = -PHI/(y'*s);
       
       M_t_prev = -beta;
       
       
       
   else
       PHI = ((1-phi(1))*(y'*s)^2)/((1-phi(1))*(y'*s)^2+phi(1)*((1/gamma)*(y'*y)*(gamma*(s'*s))));
       
       alpha = (1/(s'*y))+PHI*(1/gamma)*(y'*y)/(s'*y)^2;
       beta = -PHI/(y'*s);
       delta = -(1-PHI)/(y'*((1/gamma)*y));
       
       M_t_prev = [alpha beta; beta delta];
       
   end
    
for j=2:k
    
    Psi_tilde_y = [];
    
    for i=1:j-1
        
        if b(i) == 1
            E=eye(2);
        else
            E=[-1;1];
        end

        Psi_tilde_y = [Psi_tilde_y; E'*[YS(j,i);(1/gamma)*YY(i,j)]];
      
    end
    
 PSI_t = Psi_tilde_y; 



   p_t = M_t_prev*(PSI_t);
   
  
   
   yHy = ((1/gamma)*YY(j,j))+(PSI_t)'*p_t;
   

   PHI = ((1-phi(j))*(YS(j,j))^2)/(((1-phi(j))*(YS(j,j))^2)+phi(j)*yHy*X(j-1,1));

   
   alpha = (1+(PHI*(yHy)/(YS(j,j))))/(YS(j,j));
   
   beta = -PHI/(YS(j,j));
   
   delta = -(1-PHI)/yHy;
   
   if b(j) == 0
       M_t_current = [M_t_prev-beta*(p_t*p_t')  -beta*p_t;
                      -beta*p_t' -beta];
   else 
       M_t_current = [M_t_prev+delta*(p_t*p_t') beta*p_t delta*p_t;
                      beta*p_t' alpha beta;
                      delta*p_t' beta delta];
   end

   M_t_prev = M_t_current;
end


end
