%% function [Gamma] = Gam(Gamma,phi,s,y,B_old)
%The function Gam creates the diagonal matrix of previous 
%gamma values and the new gamma value
%Input:
%   Gamma = k x k matrix 
%   phi   = any real number
%   s     = n x 1
%   y     = n x 1
%   B_current = n x n
%   b= 0 or 1 : 0 means phi is sr1 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Gamma] = Gam(Gamma,phi,s,y,B_current,b)
if b == 0 %If b=0 then phi is sr1 therefore we use 0 as an arbitrary 
    j=0;  %place holder  
else
j = phi/((-(1-phi)/(s'*B_current*s))-(phi/(s'*y)));%current value of gamma
                                                   %is calculated
end

x = diag(Gamma);%The current entries of Gamma are extracted to a vector

x = [x; j]; % The new gamma value is added to the vector 

Gamma = diag(x);    % The new Gamma is created