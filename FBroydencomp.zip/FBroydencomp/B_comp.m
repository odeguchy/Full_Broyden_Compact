%% function [B_k , X] = B_comp(gamma,S,Y,phi,b)
%   Computes the k-th quasi-newton matrix update for the Full Broyden 
%   class using the compact representation algorithm
%
%==========================================================================
%                                   Inputs
%==========================================================================
%   gamma           Real number. Used to create the initial matrix 
%                   which is a multiple of the identity matrix
%
%   S               n x 1 vector that is one part of the quasi-Newton pair
%
%   Y               n x 1 vector that is one part of the quasi-Newton pair
%
%   phi             1 x n vector containing the values of phi for each
%                   iteriation 
%
%   b               1 x n vector indicating if phi is SR1
%                   if the ith entry of phi is SR1 then b(i) = 0
%                   if the ith entry of phi is not SR1 then b(i) = 1
%==========================================================================
%                                   Outputs
%==========================================================================
%   B_k             n x n matrix that is the k-th update of the 
%                   quasi-Newton matrix
%
%   X               k x k matrix that is the product gamma*S'S
%                   used to compute the inverse Full Broyden compact
%                   representation
%
%==========================================================================

function [B_k , X] = B_comp(gamma,S,Y,phi,b)

[n , k] = size(S);

YS = Y'*S;

SBS = gamma*(S'*S);



[M_current , X] = M_k2_0(gamma,SBS,YS,phi,k,b,S,Y);

[Psi_hat_k] = Psi_hat(gamma,S,Y,b);

B_k = gamma*eye(n)+Psi_hat_k*M_current*Psi_hat_k';


