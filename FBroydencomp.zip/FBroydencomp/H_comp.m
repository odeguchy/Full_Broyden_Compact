%% function [ r ] = H_comp(gamma,S,Y,phi,b,z)
%
% This function solves the linear equation B_k r = z by forming the inverse
% compact representation to form H_k such that r = H_k z 
%
%==========================================================================
%                                   Inputs
%==========================================================================
%   gamma           Real number. Used to create the initial matrix 
%                   which is a multiple of the identity matrix
%
%   S               n x 1 vector that is one part of the quasi-Newton pair
%
%   Y               n x 1 vector that is one part of the quasi-Newton pair
%
%   phi             1 x n vector containing the values of phi for each
%                   iteriation 
%
%   b               1 x n vector indicating if phi is SR1
%                   if the ith entry of phi is SR1 then b(i) = 0
%                   if the ith entry of phi is not SR1 then b(i) = 1
%
%   z               n x 1 vector right side of the equation B_kr = z
%==========================================================================
%                                   Outputs
%==========================================================================
%   r             n x 1 vector  solution of the equation B_kr=z
%
%==========================================================================

function [ r ] = H_comp(gamma,S,Y,phi,b,z)

k = size(S,2);

YS = Y'*S;          %Pre-multiplication of matrices whose values will be 
SBS = gamma*(S'*S); % used in 
YY = Y'*Y;


[M_current , X] = M_k2_0(gamma,SBS,YS,phi,k,b,S,Y);

[M_tilde] = M_tilde_k(gamma,X,YY,YS,S,Y,phi,k,b);

[Psi_tilde_k] = Psi_tilde(gamma,S,Y,b);

r=(1/gamma)*z+Psi_tilde_k*M_tilde*(Psi_tilde_k'*z);




