%% function [M_current , X] = M_k2_0(gamma,SBS,YS,phi,k,b,S,Y)
%
%Given the necessary inputs the matrix M_k_hat is computed according to 
%Algorithm 1 
%%Inputs:
%   gamma       = any real number such that B_0 = gamma*I_n
%   SBS         = k+1 x k+1 matrix;
%   YS          = k+1 x k+1 matrix
%   phi         = 1 x n vector 
%   k           = integer, index of the current M_hat
%   b           = n x 1 vector;  indicator: if b=0 then phi is SR1
%                                           if b=1 then phi is not SR1
%   S           = n x k+1 matrix; 
%   Y           = n x k+1 matrix;
%
%Outputs: 
%   M_current = rank x rank matrix ;
%   X         = k x 1 vector; contains the values sBs;
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [M_current , X]= M_k2_0(gamma,SBS,YS,phi,k,b,S,Y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M_0_hat is calculated 
s=S(:,1);
y=Y(:,1);

if k == 1                                 
    if b(1) == 0
        M_current = 1/(s'*(y-(gamma*s)));
    else 
        g=Gam([],phi(1),s,y,gamma,b(1));
        M = [-s'*gamma*s+g g;g s'*y+g];
        M_current = inv(M);
        
    end
    sBs=gamma*s'*s;
    
else

    if b(1) == 0
        M_prev = 1/(s'*(y-(gamma*s)));
    else 
        g=Gam([],phi(1),s,y,gamma,b(1));
        M = [-gamma*(s'*s)+g g;g (s'*y)+g];
        M_prev = inv(M);
        
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 X=[];  
for j=2:k

Psi_hat_s = [];
    
    for i=1:j-1
        
        if b(i) == 1
            E=eye(2);
        else
            E=[-1;1];
        end

        Psi_hat_s = [Psi_hat_s; E'*[SBS(i,j);YS(i,j)]];
      
    end

p = M_prev*Psi_hat_s;        

sBs = SBS(j,j)+Psi_hat_s'*p;


alpha = -(1-phi(j))/(sBs);

beta = -phi(j)/(YS(j,j));

delta = (1+phi(j)*((sBs)/(YS(j,j))))/(YS(j,j));


if b(j) == 0
M_current = [M_prev-beta*(p*p') beta*p; beta*p' -beta];
else
    
M_current = [M_prev+(alpha*(p*p')) alpha*p beta*p;
             alpha*p' alpha beta;
             beta*p' beta delta];
end
M_prev = M_current;
X=[X;sBs];

end

end