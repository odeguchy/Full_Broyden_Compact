%======================================================================= 
%           Full Broyden Class compact representation and inverse
%                   compact representation demonstration
%
%=======================================================================
%
%   This demonstration calculates B_5, the fifth quasi-Newton update to
%   the initial matrix B_0 (a multiple of the identity matrix). The Inverse
%   compact representation is used to calculate the solution to the
%   equation B_5 r = z given z. The data provided for the calculations 
%   include :
%
%   gamma   =   value used to determine the initial matrix B_0
%
%   S_4     =   n x 5 matrix of vectors that are one part of 
%               of the quasi-Newton pairs, S_4 = [s_0 s_1 s_2 s_3 s_4]
%
%   Y_4     =   n x 5 matrix of vectors that are one part of 
%               of the quasi-Newton pairs, Y_4 = [y_0 y_1 y_2 y_3 y_4]
%
%   phi     =   1 x 5 vector of phi values used at each iteration to
%               calculate the updates. Note: the values not only change
%               at each iteration but also can change between SR1 values
%               and non-SR1 values.
%
%   b       =   1 x 5 vector of values indicating if phi values are SR1
%               or not SR1 i.e. if phi(i) is SR1 then b(i) = 0 if phi(i)
%               is not SR1 then phi(i)=1
%
%   z       =   n x 1 right side of the equation B_5 r = z
%
%==========================================================================

clear all

load('Demo_Data')

[B_5] = B_comp(gamma,S,Y,phi,b);

[ r ] = H_comp(gamma,S,Y,phi,b,z);





