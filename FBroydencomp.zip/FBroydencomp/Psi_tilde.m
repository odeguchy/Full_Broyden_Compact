%% function [Psi_tilde_k] =Psi_tilde(gamma,S,Y,b)
%
% Computes the kth version of Psi_hat
%%Inputs:
%   gamma       = any real number such that B_0 = gamma*I_n
%   S           = n x k+1 matrix
%   Y           = n x k+1 matrix
%   b           = = n x 1 vector;  indicator: if b=0 then phi is SR1
%                                             if b=1 then phi is not SR1
%%%Outputs:
%  Psi_tilde_k = n x rank matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Psi_tilde_k] = Psi_tilde(gamma,S,Y,b)
Psi_tilde_k=[];

for i=1:size(b,2)
 
    if b(i) == 0
        E=[-1;1];
    else
        E=eye(2);
    end
    Psi_tilde_k = [Psi_tilde_k [S(:,i) (1/gamma)*Y(:,i)]*E];
end
